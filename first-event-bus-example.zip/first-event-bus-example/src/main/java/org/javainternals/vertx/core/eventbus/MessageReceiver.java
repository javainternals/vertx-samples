package org.javainternals.vertx.core.eventbus;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.EventBus;

public class MessageReceiver extends AbstractVerticle
{
  @Override
  public void start() throws Exception
  {
    EventBus eventBus = vertx.eventBus();
    eventBus.consumer(EventBusUtil.EVENT_BUS_ADDRESS, message -> {

      String msg = "MessageReceiver received the message : " + message.body().toString();
      System.out.println(msg);
      message.reply(msg);
    });
  }

  public static void main(String[] args)
  {
    System.out.println("Starting MessageReceiver ...");
    ApplicationStarter.runClustere(MessageReceiver.class);
  }
}
