package org.javainternals.vertx.core.eventbus;

import java.time.LocalTime;
import java.util.concurrent.TimeUnit;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.EventBus;

public class MessageSender extends AbstractVerticle
{
  @Override
  public void start() throws Exception
  {
    EventBus eventBus = vertx.eventBus();

    /**
     * Sending Hello Word On Every 5 Seconds
     */
    vertx.setPeriodic(TimeUnit.SECONDS.toMillis(5), handler -> {
      String message = "Hello Word @ " + LocalTime.now();
      eventBus.send(EventBusUtil.EVENT_BUS_ADDRESS, message, reply -> {
        if (reply.succeeded())
        {
          String replyMessage = reply.result().body().toString();
          System.out.println("Received reply: " + replyMessage);
        }
        else
        {
          System.out.println("No reply from message receiver");
        }
      });
    });
  }

  public static void main(String[] args)
  {
    System.out.println("Starting MessageSender ...");
    ApplicationStarter.runClustere(MessageSender.class);
  }
}
