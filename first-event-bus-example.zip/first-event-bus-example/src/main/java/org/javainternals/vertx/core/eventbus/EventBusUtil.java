package org.javainternals.vertx.core.eventbus;

public class EventBusUtil
{
  public static final String EVENT_BUS_ADDRESS = "vertx.eventbus.first";
}
